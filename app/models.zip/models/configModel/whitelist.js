'use strict';

module.exports = async (app) => {
  const { STRING, INTEGER } = app.Sequelize;
  const Whitelist = app.configModel.define(
    'whitelist',
    {
      id: {
        type: INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      type: {
        type: INTEGER,
        allowNull: false,
      },
      ip: {
        type: STRING(128),
        allowNull: false,
      },
      port: {
        type: INTEGER,
        allowNull: false,
      },
      protocol: {
        type: STRING(32),
      },
      comment: {
        type: STRING(255),
      },
      vsysid: {
        type: INTEGER,
      },
    },
    {
      tableName: 'whitelist',
      timestamps: false,
    }
  );

  await Whitelist.sync();

  return Whitelist;
};
